<?php
/**
* Plugin Name: Custom Registration Form
* Description: Un plugin pour créer un formulaire d'enregistrement personnalisé.
* Version: 1.0
* Author: Danny
*/
?>